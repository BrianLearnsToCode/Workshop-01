<img src="images/Picture0.png" width=250x\>

# The Internship Network in Mathematical Sciences
## Solutions to Notebooks of Workshop #1
This Workshop is a basic introduction to Python which will lay the foundations required for the rest of the INMAS program. Python has been selected as a language of choice due to its ubiquitous use in the industry and the reduced time, compared to other popular languages, for developing a prototype application. This is mainly thanks to the broad availibility of modules that were developed for the language, allowing to interface with many other programming languages (e.g., C), applications (e.g., Excel), and interfaces (e.g., the web or the operating system).

Here is an overview of the notebooks that are part of the Workshop. The two columns on the right gives an estimated time required to complete each notebook. We anticipate that you will have sufficient time to complete the core parts of the training during the Workshop. The optional parts are there to help you improve your skills and should not be completed during the Workshop unless you already have a good programming basis in Python. For beginners, we suggest that you revisit these notebooks at a later time. This wil help you assimilate the material and ensure a continuity in practicing a new programming language.

| *Notebook* | 	*Content* | *Estimated core time* | *Optional time* |
| ---------| --------------------------| --------| ------ |
|01  |  Python primer | XX | N/A |
|02  |  Additional Python practice | XX | XX |
|03  |  Modules and matplotlib | XX | XX |
|04  |  Input/Output | XX | XX |
|05a |  Rock/Paper/Scissors | XX | XX |
|05b |  Hangman | XX | XX |
|06  |  Functions | XX | XX |
|07  |  Elements of Software Engineering | XX | XX |
|08  |  Debugging fundamentals | 15mins | N/A |
|09  |  numpy basics | 25mins | N/A |
|10 |  numpy intermediate | 30 | 20 |
|11 |  Visualizing with matplotlib | 20 | 10 |
|12 |  SciPy basics | XX | XX |
|13 |  Project 1 - SIR modeling | XX | N/A |
|14 |  Introduction to pandas | XX | XX |
|15 |  Visualizing using Seaborn | XX | XX |
|16 |  Project 2 - Redfin | XX | N/A |

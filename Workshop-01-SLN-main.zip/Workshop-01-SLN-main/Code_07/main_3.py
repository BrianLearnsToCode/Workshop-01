#!/usr/bin/env python3

# A prototypical main file with parameters from command line arguments or text files
# Martin-D. Lacasse, JHU 2022

import sys
import getopt
import params2

# Print Usage
def printHelp(name):
    print("Usage: ", name, "-[h] [-a a_param] [-b b_param] [-c c_param] [-s _sourceCode] [-d DesiredOutcom]  [-f file]")
    sys.exit(1)

# Parse options from command line
def processCommandLineArgs(argv):
    progName = argv[0]
    argList =  argv[1:]

    # Options
    options = "ha:b:c:s:d:f:"
 
    # Long options for parameter
    longOptions = ["help","a=", "b=", "c=", "d=", "s=", "file="]
 
    try:
        # Parsing arguments
        opts, vals = getopt.getopt(argList,options,longOptions)
        # Checking each argument
        argMode=0 #Flag indicating if param file was used
        for opt, val in opts:
            if opt in ("-h", "--help"):
                printHelp(progName)
            elif opt in ("-a", "--a"):
                a = int(val)
            elif opt in ("-b", "--b"):
                b = int(val)
            elif opt in ("-c", "--c"):
                c = int(val)
            elif opt in ("-s", "--sourceCode"):
                sourceCode = val
            elif opt in ("-d", "--desiredOutcome"):
                desiredOutcome = val
            elif opt in ("-f", "--f"):
                argMode=1
                filename = val

    except getopt.error as err:
            print(str(err))
            printHelp(progName)
            sys.exit(2)
            
    if argMode==1:
        params = params2.readParameters(filename)
    
    for var in ['a','b','c','sourceCode','desiredOutcome']:
        if var in locals():
            if var in params:
                print("Warning: Variable '" + var + "' override")
            exec("params['"+var + "'] =" + var)
         

    return params

def run():
    params = processCommandLineArgs(sys.argv)
    print('Arguments are:')
    for key in params:
        print(key + " = " + str(params[key]))
    

#####################################################################
# This is the main program
if __name__ == "__main__":

    run()

else:
    print("Error: Can't import main script as a module.", repr(__name__))


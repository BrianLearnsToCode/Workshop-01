
Fles in this folder are used by the following notebooks:
- Notebook 04 - Input/Output
- Notebooks 09 and 10 - Numpy

